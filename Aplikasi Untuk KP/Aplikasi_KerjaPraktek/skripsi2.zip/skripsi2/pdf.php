<?php
class pdf{
    function __construct() {
        include_once APPPATH.'/fpdf/fpdf.php';

    }
}
?>