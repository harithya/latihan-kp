<?php

                            include "koneksi.php";

                            if(isset($_POST['proses'])){
                                mysqli_query($koneksi, "UPDATE master_cs set 
                                kode_produk = '$_POST[kode_produk]',
                                nama_produk = '$_POST[nama_produk]',
                                ukuran_kemasan = '$_POST[ukuran_kemasan]',
                                harga_pembelian = '$_POST[harga_pembelian]',
                                nilai_pajak = '$_POST[jenispajak]',
                                dppmasukan = '$_POST[dppmasukan]',
                                ppnmasukan = '$_POST[ppnmasukan]',
                                kuantum = '$_POST[kuantum]',
                                nominal_pembelian = '$_POST[nominal_pembelian]',
                                opslag = '$_POST[opslag]',
                                nominal_opslag = '$_POST[nominal_opslag]',
                                biaya_pengadaan = '$_POST[biaya_pengadaan]',
                                biaya_pengadaanperkg = '$_POST[biaya_pengadaanperkg]',
                                susut_kemas = '$_POST[susut_kemas]',
                                susut_simpan = '$_POST[susut_simpan]',
                                komoditi_rusak = '$_POST[komoditi_rusak]',
                                persediaan = '$_POST[persediaan]',
                                hpp = '$_POST[hpp]',
                                biaya_umum = '$_POST[biaya_umum]',
                                biaya_pegawai = '$_POST[biaya_pegawai]',
                                biaya_kantor = '$_POST[biaya_kantor]',
                                biaya_pajak = '$_POST[biaya_pajak]',
                                biaya_uitslag = '$_POST[biaya_uitslag]',
                                biaya_angkutan = '$_POST[biaya_angkutan]',
                                biaya_operasional = '$_POST[biaya_operasional]',
                                nombiaya_pegawai = '$_POST[nombiaya_pegawai]',
                                nombiaya_kantor = '$_POST[nombiaya_kantor]',
                                nombiaya_pajak = '$_POST[nombiaya_pajak]',
                                nombiaya_umum = '$_POST[nombiaya_umum]',
                                nombiaya_uitslag = '$_POST[nombiaya_uitslag]',
                                nombiaya_angkutan  = '$_POST[nombiaya_angkutan]',
                                nombiaya_operasional  = '$_POST[nombiaya_operasional]',
                                biaya_penjualan  = '$_POST[biaya_penjualan]',
                                jumlah_bulan  = '$_POST[jumlah_bulan]',
                                biaya_bunga  = '$_POST[biaya_bunga]',
                                biaya_provadm  = '$_POST[biaya_provadm]',
                                biaya_bank = '$_POST[biaya_bank]',
                                tarif_bunga = '$_POST[tarif_bunga]',
                                nombiaya_bunga = '$_POST[nombiaya_bunga]',
                                nombiaya_provadm = '$_POST[nombiaya_provadm]',
                                totbiaya_bank = '$_POST[totbiaya_bank]',
                                biaya_mbp = '$_POST[biaya_mbp]',
                                total_biaya = '$_POST[total_biaya]',
                                hp_penjualan = '$_POST[hp_penjualan]',
                                dppkeluaran = '$_POST[dppkeluaran]',
                                ppnkeluaran = '$_POST[ppnkeluaran]',
                                ppn = '$_POST[ppn]',
                                harga_jual = '$_POST[harga_jual]',
                                margin_bulog = '$_POST[margin_bulog]'
                                WHERE id_produk = '$_POST[id_produk]'");

                                echo "<script>alert('Data Cost Structure Anda Berhasil Diubah'); window.location ='tablescoststructure.php'</script>";
                            }
                            ?>
                        