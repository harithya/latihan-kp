<?php
session_start();
include"koneksi.php";
if(empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    header('location:login.php');
}else{
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Data Pelanggan</title>
    <script src="vendor/jquery/jquery.min.js"></script>
  
   

    <!-- Custom fonts for this template -->
    <link rel="shortcut icon" href="bulog.png">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Komersial Bandung</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Produk</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Components:</h6>
                        <a class="collapse-item" href="tablesjenisproduk.php">Master Jenis Produk</a>
                        <a class="collapse-item" href="tablescoststructure.php">Cost Structure</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Transaksi</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="404.php">Transaksi Penjualan</a>
                        <a class="collapse-item" href="404.php">Transaksi Penagihan</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Laporan</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="404.php">Laporan Penjualan Harian</a>
                        <a class="collapse-item" href="404.php">Laporan Penjualan Bulanan</a>
                        <a class="collapse-item" href="404.php">Laporan Per RPS</a>
                        <a class="collapse-item" href="404.php">Laporan Per Channel</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="404.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Charts</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item active">
                <a class="nav-link" href="404.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <form action="tambahcs.php" method="post" id="form_tambah" role="form" enctype="multipart/form-data" name="form_tambah"> 
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Cost Structure</h1>
                    
                    <!-- DataTales Example --> 
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">I. Perhitungan Harga Pokok Perolehan (COGS)</h6>
                        </div>
                        <div class="card-body">
                        <table border="0" cellpadding="5">
                                    <tr>
                                        <td size="100">Kode Produk</td>
                                        <td>
                                        <input value= "<?php
                                        $kodeauto = mysqli_query($koneksi, "SELECT max(kode_produk) as maxID from master_cs");
                                        $datakode = mysqli_fetch_array($kodeauto);

                                        $kode = $datakode['maxID'];

                                        $kode++;
                                        $ket = "PRD";

                                        $hasilkodeauto =sprintf("%05s",$kode);

                                        echo $hasilkodeauto;

                                        ?>" type="text" readonly="readonly" class="form-control" name="kode_produk">
                                        
                                        </td>
                                        <td></td>
                                        <td>DPP Masukan</td>
                                        <td><input type="text" class="form-control" name="dppmasukan" id="dppmasukan" readonly="readonly"></td>
                                        <td></td>
                                        <td>Kuantum Cad Susut Kemas</td>
                                        <td><input type="text" class="form-control" name="susut_kemas" id="susut_kemas" value="0"></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Produk</td>
                                        <?php
                                        $tampil2  =mysqli_query($koneksi, "SELECT * FROM master_jenisproduk");
                                        ?>

                                        <td>
                                        <select name="jenisproduk" class="form-control" id="jenisproduk" onchange="tammpil();">
                                        <option value="#">Pilih Jenis Produk</option>
                                        <?php
                                        while ($data2 =mysqli_fetch_array($tampil2)) { ?>
                                            
                                            <option value="<?php echo $data2['biaya_umum']?>"><?php echo $data2['nama_jenisproduk']?></option>
                                            <?php }?>
                                        </select>
                                        </td>  
                                        <td></td>
                                        <td>PPN Masukan</td>
                                        <td><input type="text" class="form-control" name="ppnmasukan" id="ppnmasukan" readonly="readonly"></td>
                                        <td></td>
                                        <td>Kuantum Cad Susut Simpan</td>
                                        <td><input type="text" class="form-control" name="susut_simpan" id="susut_simpan" value="0"></td>
                                    <tr>
                                        <td>Nama Produk</td>
                                        <td><input type="text" class="form-control" name="nama_produk" id="nama_produk"></td>
                                        <td></td>
                                        <td>Kuantum</td>
                                        <td><input type="number" class="form-control" name="kuantum" id="kuantum" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Kuantum Cad Komoditi Rusak</td>
                                        <td><input type="text" class="form-control" name="komoditi_rusak" id="komoditi_rusak" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Ukuran Kemasan</td>
                                        <td><input type="text" class="form-control" name="ukuran_kemasan" id="ukuran_kemasan"></td>
                                        <td></td>
                                        <td>Nominal Pembelian</td>
                                        <td><input type="text" class="form-control" name="nominal_pembelian" id="nominal_pembelian" readonly="readonly"></td>
                                        <td></td>
                                        <td>Total Biaya Pengadaan (/kg)</td>
                                        <td><input type="text" class="form-control" name="biaya_pengadaanperkg" id="biaya_pengadaanperkg"></td>
                                    </tr>
                                    </tr>
                                    <tr>
                                        <td>Jenis Barang</td>
                                        <td>
                                        <?php
                                        $tampil91  =mysqli_query($koneksi, "SELECT * FROM master_jenisbarang");
                                        ?>

                                        
                                        <select name="jenisbarang" class="form-control" id="jenisbarang" onchange="ppajak();">
                                        <option value="#">BKP / Non BKP</option>
                                        <?php
                                        while ($data91 =mysqli_fetch_array($tampil91)) { ?>
                                            
                                            <option value="<?php echo $data91['nilai_jenis']?>"><?php echo $data91['nama_jenis']?></option>
                                            <?php }?>
                                        </select>
                                        </td>  
                                        
                                        <td></td>
                                        <td>Biaya Opslag</td>
                                        <td><input type="text" class="form-control" name="opslag" id="opslag" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Harga Pokok Perolehan</td>
                                        <td><input type="text" class="form-control" name="hpp" id="hpp" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Pajak</td>
                                        <td>
                                        <?php
                                        $tampil9  =mysqli_query($koneksi, "SELECT * FROM master_pajak");
                                        ?>

                                        
                                        <select name="jenispajak" class="form-control" id="jenispajak" onchange="ppajak();">
                                        <option value="#">Pilih Jenis Pajak</option>
                                        <?php
                                        while ($data9 =mysqli_fetch_array($tampil9)) { ?>
                                            
                                            <option value="<?php echo $data9['nilai_pajak']?>"><?php echo $data9['nama_pajak']?></option>
                                            <?php }?>
                                        </select>
                                        </td>  
                                        <td></td>
                                        <td>Nominal Biaya Opslag</td>
                                        <td><input type="text" class="form-control" name="nominal_opslag" id="nominal_opslag" readonly="readonly"></td>
                                        <td></td>
                                        <td>Persediaan</td>
                                        <td><input type="text" class="form-control" name="persediaan" id="persediaan" readonly="readonly"></td>
                                   </tr>
                                    <tr>
                                        <td>Harga Pembelian</td>
                                        <td><input type="number" class="form-control" name="harga_pembelian" id="harga_pembelian" onkeyup="sum();"></td>
                                        <td></td>
                                        <td>Total Biaya Pengadaan</td>
                                        <td><input type="text" class="form-control" name="biaya_pengadaan" id="biaya_pengadaan" readonly="readonly"></td>                                        
                                    </table>

                               
                        </div>
                        <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">II. Biaya Overhead/Eksploitasi</h6>
                        </div>
                        <div class="card-body">
                            <table border="0" cellpadding="5">
                                    <tr>
                                        <td>Sewa Gudang Per Kg</td>
                                        <td><input type="text" class="form-control" name="sewa_gudang" id="sewa_gudang" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Total Sewa Gudang</td>
                                        <td><input type="text" class="form-control" name="totsewa_gudang" id="totsewa_gudang" readonly="readonly"></td>
                                        <td></td>
                                        <td>Total Biaya Eksploitasi</td>
                                        <td><input type="text" class="form-control" name="totbiaya_eksploitasi" id="totbiaya_eksploitasi" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Asuransi Komoditas Per Kg</td>
                                        <td><input type="text" class="form-control" name="asuransi_komoditas" id="asuransi_komoditas" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Total Movement Nasional</td>
                                        <td><input type="text" class="form-control" name="totasuransi_komoditas" id="totasuransi_komoditas" readonly="readonly"></td>
                                        <td></td>
                                        <td>Total Biaya Eksploitasi Per Kg</td>
                                        <td><input type="text" class="form-control" name="biaya_eksploitasiperkg" id="biaya_eksploitasiperkg" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Handling Gudang Per Kg</td>
                                        <td><input type="text" class="form-control" name="handling_gudang" id="handling_gudang" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Total Biaya Handling Gudang</td>
                                        <td><input type="text" class="form-control" name="tothandling_gudang" id="tothandling_gudang" readonly="readonly"></td>
                                    </tr>
                                   <tr>
                                        <td>Movement Nasional Per Kg</td>
                                        <td><input type="text" class="form-control" name="move_nas" id="move_nas" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Total Movement Nasional</td>
                                        <td><input type="text" class="form-control" name="totmove_nas" id="totmove_nas" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Movement Regional Per Kg</td>
                                        <td><input type="text" class="form-control" name="move_reg" id="move_reg" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Total Movement Regional</td>
                                        <td><input type="text" class="form-control" name="totmove_reg" id="totmove_reg" readonly="readonly"></td>
                                    </tr>
                                   
                                  
                            </table>
                        </div>
                        <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">III. Biaya Manajemen, Bank dan Penjualan</h6>
                        </div>
                        <div class="card-body">
                        <table border="0" cellpadding="5">
                                   <tr>
                                        <td>Biaya Pegawai</td>
                                        <td><input type="text" class="form-control" name="biaya_pegawai" id="biaya_pegawai" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Pegawai</td>
                                        <td><input type="text" class="form-control" name="nombiaya_pegawai" id="nombiaya_pegawai" readonly="readonly"></td>
                                        <td></td>
                                        <td>Jumlah Bulan </td>
                                        <td><input type="text" class="form-control" name="jumlah_bulan" id="jumlah_bulan" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Tarif Bunga </td>
                                        <td><input type="text" class="form-control" name="tarif_bunga" id="tarif_bunga" value="0" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Kantor</td>
                                        <td><input type="text" class="form-control" name="biaya_kantor" id="biaya_kantor" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Kantor</td>
                                        <td><input type="text" class="form-control" name="nombiaya_kantor" id="nombiaya_kantor" readonly="readonly"></td>
                                        <td></td>
                                        <td>Biaya Bunga</td>
                                        <td><input type="text" class="form-control" name="biaya_bunga" id="biaya_bunga" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Bunga</td>
                                        <td><input type="text" class="form-control" name="nombiaya_bunga" id="nombiaya_bunga" readonly="readonly"></td>  
                                    </tr>
                                    <tr>
                                        <td>Biaya Pajak</td>
                                        <td><input type="text" class="form-control" name="biaya_pajak" id="biaya_pajak" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Pajak</td>
                                        <td><input type="text" class="form-control" name="nombiaya_pajak" id="nombiaya_pajak" readonly="readonly"></td>
                                        <td></td>
                                        <td>Biaya Provisi Adm</td>
                                        <td><input type="text" class="form-control" name="biaya_provadm" id="biaya_provadm" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Provisi Adm</td>
                                        <td><input type="text" class="form-control" name="nombiaya_provadm" id="nombiaya_provadm" readonly="readonly"></td>   
                                    </tr>
                                    <tr>
                                        <td>Biaya Umum Per Kg</td>
                                        <td><input type="text" class="form-control" name="biaya_umum" id="biaya_umum" readonly="readonly"></td>
                                        <td></td>
                                        <td>Nominal Biaya Umum</td>
                                        <td><input type="text" class="form-control" name="nombiaya_umum" id="nombiaya_umum" readonly="readonly"></td>
                                        <td></td>
                                        <td>Biaya Bank Per Kg</td>
                                        <td><input type="text" class="form-control" name="biaya_bank" id="biaya_bank" readonly="readonly"></td> 
                                        <td></td>
                                        <td>Total Biaya Bank </td>
                                        <td><input type="text" class="form-control" name="totbiaya_bank" id="totbiaya_bank" readonly="readonly"></td>                             
                                    </tr>
                                    <tr>
                                        <td>Biaya Uitslag</td>
                                        <td><input type="text" class="form-control" name="biaya_uitslag" id="biaya_uitslag" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Nominal Biaya Uitslag</td>
                                        <td><input type="text" class="form-control" name="nombiaya_uitslag" id="nombiaya_uitslag" readonly="readonly" value="0"></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>Total Biaya MBP </td>
                                        <td><input type="text" class="form-control" name="biaya_mbp" id="biaya_mbp" readonly="readonly"></td>  
                                        
                                    </tr>
                                    <tr>
                                        <td>Biaya Angkutan</td>
                                        <td><input type="text" class="form-control" name="biaya_angkutan" id="biaya_angkutan" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Nominal Biaya Angkutan</td>
                                        <td><input type="text" class="form-control" name="nombiaya_angkutan" id="nombiaya_angkutan" readonly="readonly" value="0"></td>  
                                    </tr>
                                    <tr>
                                        <td>Biaya Operasional </td>
                                        <td><input type="text" class="form-control" name="biaya_operasional" id="biaya_operasional" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Nominal Biaya Operasional</td>
                                        <td><input type="text" class="form-control" name="nombiaya_operasional" id="nombiaya_operasional" readonly="readonly" value="0"></td>    
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>Total Biaya Penjualan </td>
                                        <td><input type="text" class="form-control" name="biaya_penjualan" id="biaya_penjualan" readonly="readonly"></td>
                                    </tr>
                                     </table>
                        </div>
                        <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">IV. Hasil Akhir</h6>
                        </div>
                        <div class="card-body">
                        <table border="0" cellpadding="5">
                                   <tr>
                                        <td>Total Biaya</td>
                                        <td><input type="text" class="form-control" name="total_biaya" id="total_biaya" readonly="readonly"></td>
                                        <td></td>
                                        <td>PPN Keluaran</td>
                                        <td><input type="text" class="form-control" name="ppnkeluaran" id="ppnkeluaran" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Harga Pokok Penjualan</td>
                                        <td><input type="text" class="form-control" name="hp_penjualan" id="hp_penjualan" readonly="readonly"></td>
                                        <td></td>
                                        <td>PPN</td>
                                        <td><input type="text" class="form-control" name="ppn" id="ppn" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Margin Bulog</td>
                                        <td><input type="text" class="form-control" name="margin_bulog" id="margin_bulog" onkeyup="sum();" value="0"></td>
                                        <td></td>
                                        <td>Harga Jual</td>
                                        <td><input type="text" class="form-control" name="harga_jual" id="harga_jual" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>DPP Keluaran</td>
                                        <td><input type="text" class="form-control" name="dppkeluaran" id="dppkeluaran" readonly="readonly"></td>
                                    </tr>
                                  
                                   </table>
                        </div>
                        <div class="modal-footer">
                        
                            <td><input class="btn btn-secondary" name="reset" type="reset" value="Cancel"></td>
                            <td><a href="tablescoststructure.php"><input type="button" class="btn btn-primary" value="Kembali"></a></td>
                            <td><input class="btn btn-primary" name="simpan" type="submit" value="Simpan"></td>
                        </div>
                    </form>
                        <?php

                            include "koneksi.php";

                            if(isset($_POST['simpan'])){
                                mysqli_query($koneksi, "INSERT INTO master_cs set
                                kode_produk = '$_POST[kode_produk]',
                                nama_produk = '$_POST[nama_produk]',
                                ukuran_kemasan = '$_POST[ukuran_kemasan]',
                                harga_pembelian = '$_POST[harga_pembelian]',
                                nilai_pajak = '$_POST[jenispajak]',
                                dppmasukan = '$_POST[dppmasukan]',
                                ppnmasukan = '$_POST[ppnmasukan]',
                                kuantum = '$_POST[kuantum]',
                                nominal_pembelian = '$_POST[nominal_pembelian]',
                                opslag = '$_POST[opslag]',
                                nominal_opslag = '$_POST[nominal_opslag]',
                                biaya_pengadaan = '$_POST[biaya_pengadaan]',
                                biaya_pengadaanperkg = '$_POST[biaya_pengadaanperkg]',
                                susut_kemas = '$_POST[susut_kemas]',
                                susut_simpan = '$_POST[susut_simpan]',
                                persediaan = '$_POST[persediaan]',
                                hpp = '$_POST[hpp]',
                                sewa_gudang = '$_POST[sewa_gudang]',
                                totsewa_gudang = '$_POST[totsewa_gudang]',
                                totbiaya_eksploitasi = '$_POST[totbiaya_eksploitasi]',
                                asuransi_komoditas = '$_POST[asuransi_komoditas]',
                                totasuransi_komoditas = '$_POST[totasuransi_komoditas]',
                                biaya_eksploitasiperkg = '$_POST[biaya_eksploitasiperkg]',
                                handling_gudang = '$_POST[handling_gudang]',
                                tothandling_gudang = '$_POST[tothandling_gudang]',
                                move_nas = '$_POST[move_nas]',
                                totmove_nas = '$_POST[totmove_nas]',
                                move_reg = '$_POST[move_reg]',
                                totmove_reg = '$_POST[totmove_reg]',
                                biaya_umum = '$_POST[biaya_umum]',
                                biaya_pegawai = '$_POST[biaya_pegawai]',
                                biaya_kantor = '$_POST[biaya_kantor]',
                                biaya_pajak = '$_POST[biaya_pajak]',
                                biaya_uitslag = '$_POST[biaya_uitslag]',
                                biaya_angkutan = '$_POST[biaya_angkutan]',
                                biaya_operasional = '$_POST[biaya_operasional]',
                                nombiaya_pegawai = '$_POST[nombiaya_pegawai]',
                                nombiaya_kantor = '$_POST[nombiaya_kantor]',
                                nombiaya_pajak = '$_POST[nombiaya_pajak]',
                                nombiaya_umum = '$_POST[nombiaya_umum]',
                                nombiaya_uitslag = '$_POST[nombiaya_uitslag]',
                                nombiaya_angkutan  = '$_POST[nombiaya_angkutan]',
                                nombiaya_operasional  = '$_POST[nombiaya_operasional]',
                                biaya_penjualan  = '$_POST[biaya_penjualan]',
                                jumlah_bulan  = '$_POST[jumlah_bulan]',
                                biaya_bunga  = '$_POST[biaya_bunga]',
                                biaya_provadm  = '$_POST[biaya_provadm]',
                                biaya_bank = '$_POST[biaya_bank]',
                                tarif_bunga = '$_POST[tarif_bunga]',
                                nombiaya_bunga = '$_POST[nombiaya_bunga]',
                                nombiaya_provadm = '$_POST[nombiaya_provadm]',
                                totbiaya_bank = '$_POST[totbiaya_bank]',
                                biaya_mbp = '$_POST[biaya_mbp]',
                                total_biaya = '$_POST[total_biaya]',
                                hp_penjualan = '$_POST[hp_penjualan]',
                                dppkeluaran = '$_POST[dppkeluaran]',
                                ppnkeluaran = '$_POST[ppnkeluaran]',
                                ppn = '$_POST[ppn]',
                                harga_jual = '$_POST[harga_jual]',
                                margin_bulog = '$_POST[margin_bulog]'");

                                echo "<script>alert('Berhasil Mendambah Data Cost Sturcture'); window.location ='tablescoststructure.php'</script>";
                            }
                            ?>
                    </div>
                  

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Yuki Yulyadin 2021 </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

     <!-- Logout Modal-->
     <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a href="logout.php" class="btn btn-primary">Logout</a>
                    </div>
                </div>
            </div>
        </div>
               
     <!-- Insert Modal-->
     <div class="modal fade" id="insertModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="tablescoststructure.php" method="post" id="form_tambah" role="form" enctype="multipart/form-data" name="form_tambah">
                        <div class="modal-header" style="background:#4e73df;color:#fff;">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Cost Structure</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true" style="color:#fff">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                       
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <td><input class="btn btn-primary" name="simpan" type="submit" value="simpan"></td>
                        </div>
                    </form>
                       
                </div>
            </div>
        </div>

         <!-- Edit Modal-->
     
    <script>
    function tammpil() {
        
      var data1 = document.getElementById("jenisproduk").value;
              
      document.getElementById("biaya_umum").value = data1;
      var result11 = parseInt(data1) * 55.57/100;
      if (!isNaN(result11)) {
         document.getElementById('biaya_pegawai').value = result11;
      } 
    
      var result12 = parseInt(data1) * 40.74/100;
      if (!isNaN(result12)) {
         document.getElementById('biaya_kantor').value = result12;
      }
      var result13 = parseInt(data1) * 3.69/100;
      if (!isNaN(result13)) {
         document.getElementById('biaya_pajak').value = result13;
      }
     
    }
    </script>

<script>
    function ppajak() {
        
      var data100 = document.getElementById("jenisbarang").value;
      var data101 = document.getElementById("harga_pembelian").value;
      var data102 = document.getElementById("jenispajak").value;
        
      document.getElementById("jenisbarang").value = data100;
      var result100 = (parseInt(data101) * parseInt(data102) * 100/111) * parseInt(data100);
      if (!isNaN(result100)) {
         document.getElementById('dppmasukan').value = result100;
      } 
      var result101 = ((parseInt(data101) - result100) * parseInt(data102))* parseInt(data100);
      if (!isNaN(result101)) {
         document.getElementById('ppnmasukan').value = result101;
      } 
    
     
     
    }
    </script>


<script>
    function sum() {
      var txtFirstNumberValue = document.getElementById('harga_pembelian').value;
      var txtSecondNumberValue = document.getElementById('kuantum').value;
      var txtTiluNumberValue = document.getElementById('nominal_pembelian').value;
      var txtHijiNumberValue = document.getElementById('opslag').value;
      var txtOpatNumberValue = document.getElementById('nominal_opslag').value;
      var txtLimaNumberValue = document.getElementById('biaya_pengadaan').value;
      var txtEnamNumberValue = document.getElementById('biaya_umum').value;
      var txtTujuhNumberValue = document.getElementById('biaya_uitslag').value;
      var txtDalapanNumberValue = document.getElementById('biaya_angkutan').value;
      var txtSalapanNumberValue = document.getElementById('biaya_operasional').value;
      var txtSapuluhNumberValue = document.getElementById('jumlah_bulan').value;
      var txtSabelasNumberValue = document.getElementById('margin_bulog').value;
      var txtDuabelasNumberValue = document.getElementById('ppnmasukan').value;
      var txtTigabelasNumberValue = document.getElementById('jenisbarang').value;
      var txtOpatbelasNumberValue = document.getElementById('sewa_gudang').value;
      var txtLimabelasNumberValue = document.getElementById('asuransi_komoditas').value;
      var txtGenepbelasNumberValue = document.getElementById('handling_gudang').value;
      var txtTujuhbelasNumberValue = document.getElementById('move_nas').value;
      var txtDalapanbelasNumberValue = document.getElementById('move_reg').value;
      var data90 = document.getElementById("jenispajak").value;
      var txtTilubelasNumberValue = document.getElementById('jenisbarang').value;
      

      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result)) {
         document.getElementById('nominal_pembelian').value =result;
      }
      var result90 = (parseInt(txtFirstNumberValue) * parseInt(data90) * 100/111) * parseInt(txtTilubelasNumberValue);
      if (!isNaN(result90)) {
         document.getElementById('dppmasukan').value = result90;
      } 
      var result91 = ((parseInt(txtFirstNumberValue) - result90) * parseInt(data90))* parseInt(txtTilubelasNumberValue);
      if (!isNaN(result91)) {
         document.getElementById('ppnmasukan').value = result91;
      } 
      var result1 = parseInt(txtHijiNumberValue) * parseInt(txtSecondNumberValue);
      if (!isNaN(result1)) {
         document.getElementById('nominal_opslag').value =result1;
      }
      var result2 = result + result1;
      if (!isNaN(result2)) {
         document.getElementById('biaya_pengadaan').value =result2;
      }
      var result3 = parseInt(txtSecondNumberValue) * 1/10000;
      if (!isNaN(result3)) {
         document.getElementById('komoditi_rusak').value = result3;
      }
      var result4 = parseInt(txtSecondNumberValue) - result3 ;
      if (!isNaN(result4)) {
         document.getElementById('persediaan').value = result4;
      }
      var result5 = result2 / result4;
      if (!isNaN(result5)) {
         document.getElementById('hpp').value =result5;
      }
      var result6 = parseInt(txtEnamNumberValue)  * result4;
      if (!isNaN(result6)) {
         document.getElementById('nombiaya_umum').value =result6;
      }
      var result7 = result6 * 55.57/100;
      if (!isNaN(result7)) {
         document.getElementById('nombiaya_pegawai').value =result7;
      }
      var result8 = result6 * 40.74/100;
      if (!isNaN(result8)) {
         document.getElementById('nombiaya_kantor').value =result8;
      }
      var result9 = result6 * 3.69/100;
      if (!isNaN(result9)) {
         document.getElementById('nombiaya_pajak').value =result9;
      }
      var result10 = result4 * parseInt(txtTujuhNumberValue);
      if (!isNaN(result10)) {
         document.getElementById('nombiaya_uitslag').value =result10;
      }
      var result11 = result4 * parseInt(txtDalapanNumberValue);
      if (!isNaN(result11)) {
         document.getElementById('nombiaya_angkutan').value =result11;
      }
      var result12 = result4 * parseInt(txtSalapanNumberValue);
      if (!isNaN(result12)) {
         document.getElementById('nombiaya_operasional').value =result12;
      }
      var result13 = result10 + result11 + result12  ;
      if (!isNaN(result13)) {
         document.getElementById('biaya_penjualan').value =result13;
      }
      var result30 = parseInt(txtOpatbelasNumberValue)  * parseInt(txtSecondNumberValue);
      if (!isNaN(result30)) {
         document.getElementById('totsewa_gudang').value =result30;
      }
      var result31 = parseInt(txtLimabelasNumberValue)  * parseInt(txtSecondNumberValue);
      if (!isNaN(result31)) {
         document.getElementById('totasuransi_komoditas').value =result31;
      }
      var result32 = parseInt(txtGenepbelasNumberValue)  * parseInt(txtSecondNumberValue);
      if (!isNaN(result32)) {
         document.getElementById('tothandling_gudang').value =result32;
      }
      var result33 = parseInt(txtTujuhbelasNumberValue)  * parseInt(txtSecondNumberValue);
      if (!isNaN(result33)) {
         document.getElementById('totmove_nas').value =result33;
      }
      var result34 = parseInt(txtDalapanbelasNumberValue)  * parseInt(txtSecondNumberValue);
      if (!isNaN(result34)) {
         document.getElementById('totmove_reg').value =result34;
      }
      var result35 = result30 + result31 + result32 + result33 + result34;
      if (!isNaN(result35)) {
         document.getElementById('totbiaya_eksploitasi').value =result35;
      }
      var result36 = result35 / result4;
      if (!isNaN(result36)) {
         document.getElementById('biaya_eksploitasiperkg').value =result36;
      }
      var result14 = (result2 + result6 + result13 + result35) * 1/1000  ;
      if (!isNaN(result14)) {
         document.getElementById('nombiaya_provadm').value =result14;
      }
      var result15 = result14 / result4 ;
      if (!isNaN(result15)) {
         document.getElementById('biaya_provadm').value =result15;
      }
      var result16 = parseInt(txtSapuluhNumberValue) * ((75/1000)/12);
      if (!isNaN(result16)) {
         document.getElementById('tarif_bunga').value = result16;
      }
      var result17 = result16 * (result2 + result6 + result13 + result35);
      if (!isNaN(result17)) {
         document.getElementById('nombiaya_bunga').value =result17;
      }
      var result18 = result17 / result4;
      if (!isNaN(result18)) {
         document.getElementById('biaya_bunga').value =result18;
      }
      var result19 = result17 + result14;
      if (!isNaN(result19)) {
         document.getElementById('totbiaya_bank').value =result19;
      }
      var result20 = result19 / result4;
      if (!isNaN(result20)) {
         document.getElementById('biaya_bank').value =result20;
      }
      var result21 = result19 + result13 + result6;
      if (!isNaN(result21)) {
         document.getElementById('biaya_mbp').value =result21;
      }
      var result22 = result21 + result2;
      if (!isNaN(result22)) {
         document.getElementById('total_biaya').value =result22;
      }
      var result23 = result22 / result4;
      if (!isNaN(result23)) {
         document.getElementById('hp_penjualan').value =result23;
      }
      var result25 = parseInt(txtFirstNumberValue) + parseInt(txtHijiNumberValue);
      if (!isNaN(result25)) {
         document.getElementById('biaya_pengadaanperkg').value =result25;
      }
      var result26 = result23 + parseInt(txtSabelasNumberValue);
      if (!isNaN(result26)) {
         document.getElementById('dppkeluaran').value =result26;
      }
      var result27 = (result26 * 11/100) * parseInt(txtTigabelasNumberValue);
      if (!isNaN(result27)) {
         document.getElementById('ppnkeluaran').value =result27;
      }
      var result28 = (result27 - parseInt(txtDuabelasNumberValue)) * parseInt(txtTigabelasNumberValue);
      if (!isNaN(result28)) {
         document.getElementById('ppn').value =result28;
      }
      var result29 = result26 + result28;
      if (!isNaN(result29)) {
         document.getElementById('harga_jual').value =result29;
      }
     
    }
    
    
</script>






    
                    

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
</html>
<?php
}
?>