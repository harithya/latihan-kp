<?php
include "koneksi.php";
    $delete=mysqli_query($koneksi,"DELETE FROM master_cs WHERE id_produk='$_GET[id_produk]'");
    if($delete) {
        header("location:tablescoststructure.php");
        }else{
            echo"Gagal Menghapus";
        }
?>