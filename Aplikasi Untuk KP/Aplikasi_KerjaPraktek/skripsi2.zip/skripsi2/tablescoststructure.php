<?php
session_start();
include"koneksi.php";
if(empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    header('location:login.php');
}else{
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Data Pelanggan</title>
    <script src="vendor/jquery/jquery.min.js"></script>
    

    <!-- Custom fonts for this template -->
    <link rel="shortcut icon" href="bulog.png">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Cabang Bandung</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Produk</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Components:</h6>
                        <a class="collapse-item" href="tablesjenisproduk.php">Master Jenis Produk</a>
                        <a class="collapse-item" href="tablescoststructure.php">Cost Structure</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Transaksi</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="404.php">Transaksi Penjualan</a>
                        <a class="collapse-item" href="404.php">Transaksi Penagihan</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Laporan</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="404.php">Laporan Penjualan Harian</a>
                        <a class="collapse-item" href="404.php">Laporan Penjualan Bulanan</a>
                        <a class="collapse-item" href="404.php">Laporan Per RPS</a>
                        <a class="collapse-item" href="404.php">Laporan Per Channel</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="404.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Charts</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item active">
                <a class="nav-link" href="404.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Kantor Cabang Bandung</span>
                                <img class="img-profile rounded-circle"
                                    src="img/bulog.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Cost Structure</h1>
                    
                        <a href="tambahcs.php" style="margin-right :0.5pc;" 
							class="btn btn-primary btn-md pull-right">
							<i class="fa fa-plus"></i> Insert Data</a>
						
						
						<div class="clearfix"></div>
						<br/>
                                 

                    <!-- DataTales Example --> 
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Cost Structure</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <thead >
                                        <tr>
                                            <th style="background:#4e73df;color:#fff;">No</th>
                                            <th style="background:#4e73df;color:#fff;">Kode Produk</th>
                                            <th style="background:#4e73df;color:#fff;">Nama Produk</th>
                                            <th style="background:#4e73df;color:#fff;">Ukuran Kemasam</th>
                                            <th style="background:#4e73df;color:#fff;">Harga Pembelian</th>
                                            <th style="background:#4e73df;color:#fff;">Kuantum</th>
                                            <th style="background:#4e73df;color:#fff;">Harga Pokok Penjualan</th>
                                            <th style="background:#4e73df;color:#fff;">Margin</th>
                                            <th style="background:#4e73df;color:#fff;">Harga Jual</th>
                                            <th style="background:#4e73df;color:#fff;">aksi</th>
                                        </tr>
                                        <?php
                                         $batas = 10;
                                         $halaman = isset($_GET['halaman'])?(int)$_GET['halaman'] : 1;
                                         $halaman_awal = ($halaman>1) ? ($halaman * $batas) - $batas : 0;
                         
                                         $sebelumnya = $halaman - 1;
                                         $selanjutnya = $halaman + 1;
                         
                                         $sql=mysqli_query($koneksi,"SELECT * FROM master_cs");
                                         $jumlah_data = mysqli_num_rows($sql);
                                         $total_halaman = ceil($jumlah_data / $batas);
                         
                                         $tampil=mysqli_query($koneksi,"SELECT * FROM master_cs order by id_produk ASC limit $halaman_awal, $batas");
                                         $nomor = $halaman_awal+1;
                                                       
                                         while($data=mysqli_fetch_array($tampil)){

                                         $hasilharga_pembelian=number_format($data['harga_pembelian'],2,',','.');
                                         $hasil_kuantum=number_format($data['kuantum'],0,',','.');
                                         $hasil_hppenjualan=number_format($data['hp_penjualan'],2,',','.');
                                         $hasil_marginbulog=number_format($data['margin_bulog'],2,',','.');
                                         $hasil_hargajual=number_format($data['harga_jual'],2,',','.');

                                         echo"<tr>
                                         <td>$nomor</td>
                                         <td>$data[kode_produk]</td>
                                         <td>$data[nama_produk]</td>
                                         <td>$data[ukuran_kemasan]</td>
                                         <td>$hasilharga_pembelian</td>
                                         <td>$hasil_kuantum</td>
                                         <td>$hasil_hppenjualan</td>
                                         <td>$hasil_marginbulog</td>
                                         <td>$hasil_hargajual</td>
                                         <td>
                                            <a href='detailproduk.php?id_produk=$data[id_produk]'><button class='btn btn-primary btn-xs'>Details</button></a>
                                            <a href='editproduk.php?id_produk=$data[id_produk]'><button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editModal'>Edit</button></a>
                                            <a href='deleteproduk.php?id_produk=$data[id_produk]'><button class='btn btn-danger btn-xs'>Hapus</button></a> 
                                            <a href='laporancs.php?id_produk=$data[id_produk]'><button class='btn btn-danger btn-xs'>Print</button></a>
                                            <a href='laporancs2.php?id_produk=$data[id_produk]'><button class='btn btn-danger btn-xs'>Print2</button></a>                                              
                                         </td>
                                         </tr>";
                                             ?>
                                             <?php
                                             $nomor++;
                                             }
                                             ?>
                                    </thead>
                                </table>
                                <p align="center">
                                    <a class="btn btn-skin btn-lg" <?php if($halaman > 1){ echo "href='?halaman=$sebelumnya'";} ?>
                                        >Sebelumnya
                                    </a>

                                    <?php
                                        for ($i=1;$i<=$total_halaman;$i++) 
                                        {
                                     ?>

                                        <a class="btn btn-skin btn-lg" href="?halaman=<?php echo $i ?>">
                                            <?php echo $i; ?>
                                            </a> 

                                            <?php
                                                }
                                                ?>

                                                <a class="btn btn-skin btn-lg" <?php if($halaman < $total_halaman) { echo "href='?halaman=$selanjutnya'"; } ?> 
                                                >Selanjutnya
                                                </a>
                                 </p>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Yuki Yulyadin 2021 </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

     <!-- Logout Modal-->
     <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a href="logout.php" class="btn btn-primary">Logout</a>
                    </div>
                </div>
            </div>
        </div>
               
     <!-- Insert Modal-->
     <div class="modal fade" id="insertModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="tablescoststructure.php" method="post" id="form_tambah" role="form" enctype="multipart/form-data" name="form_tambah">
                        <div class="modal-header" style="background:#4e73df;color:#fff;">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Cost Structure</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true" style="color:#fff">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <table border="0" cellpadding="4">
                                    <tr>
                                        <td size="90">Kode Produk</td>
                                        <td>
                                        <input value= "<?php
                                        $kodeauto = mysqli_query($koneksi, "SELECT max(kode_produk) as maxID from master_cs");
                                        $datakode = mysqli_fetch_array($kodeauto);

                                        $kode = $datakode['maxID'];

                                        $kode++;
                                        $ket = "CST";

                                        $hasilkodeauto =sprintf("%05s",$kode);

                                        echo $hasilkodeauto;

                                        ?>" type="text" readonly="readonly" class="form-control" name="kode_produk">
                                        
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Produk</td>
                                        <?php
                                        $tampil2  =mysqli_query($koneksi, "SELECT * FROM master_jenisproduk");
                                        ?>

                                        <td>
                                        <select name="jenisproduk" class="form-control" id="jenisproduk" onchange="tammpil();">
                                        <option value="#">Pilih Jenis Produk</option>
                                        <?php
                                        while ($data2 =mysqli_fetch_array($tampil2)) { ?>
                                            
                                            <option value="<?php echo $data2['biaya_umum']?>"><?php echo $data2['nama_jenisproduk']?></option>
                                            <?php }?>
                                        </select>
                                        </td>                                   
                                    </tr>
                                    <tr>
                                        <td>Nama Produk</td>
                                        <td><input type="text" class="form-control" name="nama_produk" id="nama_produk"></td>
                                    </tr>
                                    <tr>
                                        <td>Ukuran Kemasan</td>
                                        <td><input type="text" class="form-control" name="ukuran_kemasan" id="ukuran_kemasan"></td>
                                    </tr>
                                    <tr>
                                        <td>Harga Pembelian</td>
                                        <td><input type="currency" class="form-control" name="harga_pembelian" id="harga_pembelian" onkeyup="sum();"></td>
                                    </tr>
                                    <tr>
                                        <td>Kuantum</td>
                                        <td><input type="text" class="form-control" name="kuantum" id="kuantum" onkeyup="sum();"></td>
                                    </tr>
                                    <tr>
                                        <td>Nominal</td>
                                        <td><input data-type="currency" class="form-control" name="nominal" id="nominal" readonly="readonly" value="0" onkeyup="sum();"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Opslag</td>
                                        <td><input type="text" class="form-control" name="opslag" id="opslag" onkeyup="sum();"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Umum</td>
                                        <td><input type="text" class="form-control" name="biaya_umum" id="biaya_umum" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Pegawai</td>
                                        <td><input type="text" class="form-control" name="biaya_pegawai" id="biaya_pegawai" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Kantor</td>
                                        <td><input type="text" class="form-control" name="biaya_kantor" id="biaya_kantor" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Pajak</td>
                                        <td><input type="text" class="form-control" name="biaya_pajak" id="biaya_pajak" readonly="readonly"></td>
                                    </tr>
                                    <tr>
                                        <td>Dasar Faks</td>
                                        <td><input type="text" class="form-control" name="dasar_faks"></td>
                                        <td></td>
                                        <td>Dasar Faks</td>
                                        <td><input type="text" class="form-control" name="dasar_faks"></td>
                                    </tr>
                                  
                                </table>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <td><input class="btn btn-primary" name="simpan" type="submit" value="simpan"></td>
                        </div>
                    </form>
                        <?php

                                include "koneksi.php";

                                if(isset($_POST['simpan'])){
                                    mysqli_query($koneksi, "INSERT INTO master_jenisproduk set
                                    kode_jenisproduk = '$_POST[kode_jenisproduk]',
                                    nama_jenisproduk = '$_POST[nama_jenisproduk]',
                                    biaya_umum = '$_POST[biaya_umum]',
                                    biaya_pegawai = '$_POST[biaya_pegawai]',
                                    biaya_kantor  = '$_POST[biaya_kantor]',
                                    biaya_pajak = '$_POST[biaya_pajak]',
                                    dasar_faks = '$_POST[dasar_faks]'");

                                    echo "<script>alert('Berhasil Mendambah Data Jenis Produk'); window.location ='tablesjenisproduk.php'</script>";
                                }
                                ?>
                </div>
            </div>
        </div>

         <!-- Edit Modal-->
     
    <script>
    function tammpil() {
        
      var data1 = document.getElementById("jenisproduk").value;
      
      document.getElementById("biaya_umum").value = data1;
      var result1 = parseInt(data1) * 55.57/100;
      if (!isNaN(result1)) {
         document.getElementById('biaya_pegawai').value = result1;
      } 
    
      var result2 = parseInt(data1) * 40.74/100;
      if (!isNaN(result2)) {
         document.getElementById('biaya_kantor').value = result2;
      }
      var result3 = parseInt(data1) * 3.69/100;
      if (!isNaN(result3)) {
         document.getElementById('biaya_pajak').value = result3;
      }
    }
    </script>



    


    
                    

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>
</html>
<?php
}
?>