<?php

                            include "koneksi.php";

                            if(isset($_POST['proses'])){
                                mysqli_query($koneksi, "UPDATE master_jenisproduk set 
                                kode_jenisproduk = '$_POST[kode_jenisproduk]', 
                                nama_jenisproduk = '$_POST[nama_jenisproduk]',
                                biaya_umum = '$_POST[biaya_umum]',
                                biaya_pegawai = '$_POST[biaya_pegawai]',
                                biaya_kantor = '$_POST[biaya_kantor]',
                                biaya_pajak = '$_POST[biaya_pajak]',
                                dasar_faks = '$_POST[dasar_faks]'
                                WHERE id_jenisproduk = '$_POST[id_jenisproduk]'");

                                echo "<script>alert('Data Jenis Produk Anda Berhasil Diubah'); window.location ='tablesjenisproduk.php'</script>";
                            }
                            ?>